<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Polytechnic Course Registration System (PCRS)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container mt-4">
    <nav class="navbar navbar-dark bg-dark px-3">
        <span class="navbar-brand">Polytechnic Course Registration System (PCRS)</span>

        <?php if (isset($_SESSION["user_id"])): ?>
            <div>
                <a href="dashboard.php" class="btn btn-light btn-sm">Dashboard</a>
                <a href="courses.php" class="btn btn-light btn-sm">Courses</a>
                <a href="logout.php" class="btn btn-light btn-sm">Logout</a>
            </div>
        <?php endif; ?>
    </nav>
